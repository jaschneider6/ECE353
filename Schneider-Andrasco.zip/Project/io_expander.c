#include "io_expander.h"

bool io_expander_init(void){
	
	if(gpio_enable_port(IO_EXPANDER_GPIO_BASE) == false)
		return false;
	
	// Configure SCL 
  if(gpio_config_digital_enable(IO_EXPANDER_GPIO_BASE, IO_EXPANDER_I2C_SCL_PIN)== false)
  {
    return false;
  }
    
  if(gpio_config_alternate_function(IO_EXPANDER_GPIO_BASE, IO_EXPANDER_I2C_SCL_PIN)== false)
  {
    return false;
  }
    
  if(gpio_config_port_control(IO_EXPANDER_GPIO_BASE, IO_EXPANDER_I2C_SCL_PCTL_M, IO_EXPANDER_I2C_SCL_PIN_PCTL)== false)
  {
    return false;
  }
	
	// Configure SDA 
  if(gpio_config_digital_enable(IO_EXPANDER_GPIO_BASE, IO_EXPANDER_I2C_SDA_PIN)== false)
  {
    return false;
  }
    
  if(gpio_config_open_drain(IO_EXPANDER_GPIO_BASE, IO_EXPANDER_I2C_SDA_PIN)== false)
  {
    return false;
  }
    
  if(gpio_config_alternate_function(IO_EXPANDER_GPIO_BASE, IO_EXPANDER_I2C_SDA_PIN)== false)
  {
    return false;
  }
    
  if(gpio_config_port_control(IO_EXPANDER_GPIO_BASE, IO_EXPANDER_I2C_SDA_PCTL_M, IO_EXPANDER_I2C_SDA_PIN_PCTL)== false)
  {
    return false;
  }
	
	gpio_enable_port(GPIOF_BASE);
  gpio_config_digital_enable( GPIOF_BASE, PF0);
  gpio_config_enable_input( GPIOF_BASE, PF0);
  gpio_config_enable_pullup( GPIOF_BASE, PF0);
	gpio_config_falling_edge_irq(GPIOF_BASE, PF0);
	
	NVIC_SetPriority(GPIOF_IRQn,1);
	NVIC_EnableIRQ(gpio_get_irq_num(GPIOF_BASE));
	
	//  Initialize the I2C peripheral
  if( initializeI2CMaster(IO_EXPANDER_I2C_BASE)!= I2C_OK)
  {
    return false;
  }
	
	io_expander_write_reg(MCP23017_IODIRA_R, 0x0);
	io_expander_write_reg(MCP23017_IODIRB_R, 0xF);
	io_expander_write_reg(MCP23017_GPPUB_R, 0xF);
	io_expander_write_reg(MCP23017_DEFVALB_R, 0xF);
	io_expander_write_reg(MCP23017_INTCONB_R, 0x0);
	io_expander_write_reg(MCP23017_GPINTENB_R, 0xF);
  
  return true;
}

uint8_t io_expander_read_reg(uint8_t reg){
	
	uint8_t data;
  i2c_status_t status;
  // Before doing anything, make sure the I2C device is idle
  while ( I2CMasterBusy( IO_EXPANDER_I2C_BASE)) {};

	status = i2cSetSlaveAddr( IO_EXPANDER_I2C_BASE, MCP23017_DEV_ID, I2C_WRITE);

	status = i2cSendByte( IO_EXPANDER_I2C_BASE, reg, I2C_MCS_START | I2C_MCS_RUN);

	status = i2cSetSlaveAddr( IO_EXPANDER_I2C_BASE, MCP23017_DEV_ID, I2C_READ);

  status = i2cGetByte( IO_EXPANDER_I2C_BASE, &data,I2C_MCS_START | I2C_MCS_RUN | I2C_MCS_STOP);

  return data;
}
void io_expander_write_reg(uint8_t reg, uint8_t data){
  i2c_status_t status;
  // Before doing anything, make sure the I2C device is idle
  while ( I2CMasterBusy( IO_EXPANDER_I2C_BASE)) {};

	status = i2cSetSlaveAddr( IO_EXPANDER_I2C_BASE, MCP23017_DEV_ID, I2C_WRITE);

  status = i2cSendByte( IO_EXPANDER_I2C_BASE,reg ,I2C_MCS_START | I2C_MCS_RUN);

	status = i2cSendByte( IO_EXPANDER_I2C_BASE,data ,I2C_MCS_RUN | I2C_MCS_STOP);

}
void led_kill_count(uint8_t counter){
	io_expander_write_reg(MCP23017_GPIOA_R, counter);
}