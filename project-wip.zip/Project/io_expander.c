#include "io_expander.h"

uint8_t io_expander_read_reg(uint8_t reg){
	
	uint8_t data;
  
  // Before doing anything, make sure the I2C device is idle
  while ( I2CMasterBusy(IO_EXPANDER_GPIO_BASE)) {};

  //==============================================================
  // Set the I2C slave address to be the EEPROM and in Write Mode
	// ADD CODE
  //==============================================================
	i2cSetSlaveAddr(IO_EXPANDER_GPIO_BASE, MCP23017_DEV_ID, I2C_WRITE);

  //==============================================================
  // Send the Upper byte of the address
	// ADD CODE
  //==============================================================
	i2cSendByte(IO_EXPANDER_GPIO_BASE, reg, I2C_MCS_START | I2C_MCS_RUN);

  //==============================================================
  // Set the I2C slave address to be the EEPROM and in Read Mode
	// ADD CODE
  //==============================================================
	i2cSetSlaveAddr(IO_EXPANDER_GPIO_BASE, MCP23017_DEV_ID, I2C_READ);

  //==============================================================
  // Read the data returned by the EEPROM
	// ADD CODE
  //==============================================================
  i2cGetByte(IO_EXPANDER_GPIO_BASE, &data,I2C_MCS_START | I2C_MCS_RUN | I2C_MCS_STOP);

  return data;
}
void io_expander_write_reg(uint8_t address, uint8_t data){
  
  // Before doing anything, make sure the I2C device is idle
  while ( I2CMasterBusy(IO_EXPANDER_GPIO_BASE)) {};

  //==============================================================
  // Set the I2C address to be the EEPROM
	// ADD CODE
  //==============================================================
	i2cSetSlaveAddr(IO_EXPANDER_GPIO_BASE, MCP23017_DEV_ID, I2C_WRITE);

  
  //==============================================================
  // Send the Upper byte of the address
	// ADD CODE	
  //==============================================================
	i2cSendByte(IO_EXPANDER_GPIO_BASE,(uint8_t)(address>>8) ,I2C_MCS_START | I2C_MCS_RUN);

		
  //==============================================================
  // Send the Lower byte of the address
	// ADD CODE
  //==============================================================
  i2cSendByte(IO_EXPANDER_GPIO_BASE,(uint8_t)address ,I2C_MCS_RUN);
			
  //==============================================================
  // Send the Byte of data to write
	// ADD CODE
  //==============================================================
	i2cSendByte(IO_EXPANDER_GPIO_BASE,data ,I2C_MCS_RUN | I2C_MCS_STOP);

}
void led_kill_count(uint8_t counter){
	io_expander_write_reg(MCP23017_GPIOA_R, counter);
}