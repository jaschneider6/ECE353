#ifndef __PROJ_IMAGES_H__
#define __PROJ_IMAGES_H__

#include <stdint.h>

/* Bitmap info for space_ship */
extern const uint8_t space_shipBitmaps[];
extern const uint8_t space_shipWidthPixels;
extern const uint8_t space_shipHeightPixels;

// Bitmap info for invader
extern const uint8_t invaderBitmaps[];
extern const uint8_t invaderWidthPixels;
extern const uint8_t invaderHeightPixels;


#endif
